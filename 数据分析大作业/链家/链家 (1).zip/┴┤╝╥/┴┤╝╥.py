"""
[课程内容]: Python采集链家二手房源数据信息 并做可视化展示

[授课老师]: 青灯教育-自游  上课时间: 20:05

[环境使用]:
    Python 3.8
    Pycharm

[模块使用]:
    requests  >>> pip install requests  数据请求模块
    parsel  >>> pip install parsel 数据解析模块
    csv  内置模块
---------------------------------------------------------------------------------------------------
win + R 输入cmd 输入安装命令 pip install 模块名 (如果你觉得安装速度比较慢, 你可以切换国内镜像源)
先听一下歌 等一下后面进来的同学,20:05正式开始讲课 [有什么喜欢听得歌曲 也可以在公屏发一下]
相对应的安装包/安装教程/激活码/使用教程/学习资料/工具插件 可以加木子老师微信
---------------------------------------------------------------------------------------------------
听课建议:
    1. 对于本节课讲解的内容, 有什么不明白的地方 可以直接在公屏上面提问, 具体哪行代码不清楚 具体那个操作不明白
    2. 不要跟着敲代码, 先听懂思路, 课后找木子老师领取录播, 然后再写代码 <如果你可以听到最后的话, 可以给你赠送代码学习的>
    3. 不要进进出出, 早退不仅没有录播, 你还会思路中断
---------------------------------------------------------------------------------------------------
模块安装问题:
    - 如果安装python第三方模块:
        1. win + R 输入 cmd 点击确定, 输入安装命令 pip install 模块名 (pip install requests) 回车
        2. 在pycharm中点击Terminal(终端) 输入安装命令
    - 安装失败原因:
        - 失败一: pip 不是内部命令
            解决方法: 设置环境变量

        - 失败二: 出现大量报红 (read time out)
            解决方法: 因为是网络链接超时,  需要切换镜像源
                清华：https://pypi.tuna.tsinghua.edu.cn/simple
                阿里云：https://mirrors.aliyun.com/pypi/simple/
                中国科技大学 https://pypi.mirrors.ustc.edu.cn/simple/
                华中理工大学：https://pypi.hustunique.com/
                山东理工大学：https://pypi.sdutlinux.org/
                豆瓣：https://pypi.douban.com/simple/
                例如：pip3 install -i https://pypi.doubanio.com/simple/ 模块名

        - 失败三: cmd里面显示已经安装过了, 或者安装成功了, 但是在pycharm里面还是无法导入
            解决方法: 可能安装了多个python版本 (anaconda 或者 python 安装一个即可) 卸载一个就好
                    或者你pycharm里面python解释器没有设置好
---------------------------------------------------------------------------------------------------
如何配置pycharm里面的python解释器?
    1. 选择file(文件) >>> setting(设置) >>> Project(项目) >>> python interpreter(python解释器)
    2. 点击齿轮, 选择add
    3. 添加python安装路径
---------------------------------------------------------------------------------------------------
pycharm如何安装插件?
    1. 选择file(文件) >>> setting(设置) >>> Plugins(插件)
    2. 点击 Marketplace  输入想要安装的插件名字 比如:翻译插件 输入 translation / 汉化插件 输入 Chinese
    3. 选择相应的插件点击 install(安装) 即可
    4. 安装成功之后 是会弹出 重启pycharm的选项 点击确定, 重启即可生效
---------------------------------------------------------------------------------------------------
零基础 0
有基础 1 <自己有实现过爬虫案例的>

爬虫 >>> 采集网页上面的数据程序
    Python模拟浏览器对于网址 发送请求, 获取服务器返回数据内容

采集数据之后, 没有什么特别的价值 <除非电话号码 商家电话>
    数据分析 采集长沙二手房数据, 了解长沙二手房基本行情 那个区的房子基本大概信息

python方向了解?
    人工智能
    爬虫程序
    数据分析
    网站开发
    自动化脚本
    ...

爬虫有自己的一套模板 <通用>

一. 数据来源分析
    1. 确定自己采集数据是什么, 并且这些数据可以从那里获取到
        链家网站数据, 静态网页.... <你所看到的数据, 都来于网页源代码>

二. 代码实现步骤过程
    1. 发送请求, 对于url地址发送请求 https://cs.lianjia.com/ershoufang/104108672997.html
    2. 获取数据, 获取网页源代码数据
    3. 解析数据, 提取我们想要的数据内容
    4. 保存数据, 把数据保存到表格里面

按时听课, 按时完成作业 我可以保证你学会掌握.... <因为我们青灯教育教学质量服务不到位,导致你学不会 全额退款>

    签订合同 对你负责...
你学完之后, 我们有就业指导
    提供简历的修改和制作 <100%面试机会>

    爬虫无非就是换一种快速高效复制粘贴工具 <控制速度>

报名课程学习, 但是你有福利, 优惠 <你觉得学费有压力, 还是觉得不值得>

新班开班下周三
    - 8880的学费, 你学完出去之后可以直接找8-15K薪资
    - 找清风老师 预定300学费 可以领取1042 521*2 = 1040 >>> 7540
    - 申请办理12期分期免息学习 支付宝花呗, 京东白条 信用卡 或者 腾讯课堂官方教育分期渠道
        0利息0手续费  利息手续费都是由青灯教育给大家承担 分期是下个月才支付学费
        7540 / 12 = 628/月
        可以找清风 预定300学费给你申请办理18期分期 <前三位>
        7540 / 18 = 418

    - 会直接提供两个外包订单 100-1000不等 100-300左右简单
        1-2外包订单学费就有
    - 额外赠送价值 1680元自动化办公课程
    - 享有三期学习权限 2年学习权限
        一遍之后, 在学第二遍, 再学三遍
"""# # 导入数据请求模块
import requests
# 导入数据解析模块
import parsel
import re
import csv
import urllib3
import logging
logging.captureWarnings(True)
urllib3.disable_warnings()
requests.packages.urllib3.disable_warnings()

f = open('二手房多页gz.csv', mode='a', encoding='utf-8', newline='')
csv_writer = csv.DictWriter(f, fieldnames=[
    '标题',
    '卖点',
    '总价',
    '单价',
    '户型',
    '楼层',
    '共有楼层数',
    '装修',
    '朝向',
    '建造时间',
    '面积',
    '小区',
    '区域',
    '所属区',
    '梯户比例',
    '是否有电梯',
    '房屋属性',
    '详情页',
])
csv_writer.writeheader()
"""
发送请求
    1. 确定请求网址是什么
    2. 请求方式
    3. 伪装模拟浏览器
        headers >>> 请求头加什么数据, 怎么找呢?
            User-Agent: 用户代理 表示浏览器基本身份标识... <相当于你进超市, 要看健康码或者戴口罩>
        如果你不加headers对于某些网站, 你可能被识别出来是你爬虫程序, 被反爬 >>> 得不到数据
        headers 字典数据类型
"""
for page in range(1, 21):
    url = f'https://gz.lianjia.com/ershoufang/pg{page}/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53'
    }
    response = requests.get(url=url, headers=headers,verify=False)
    # print(response.text)
    selector = parsel.Selector(response.text)
    # 真正的掌握css选择器解析方法 在系统课程都是需要学习2.5个小时左右
    href = selector.css('.sellListContent li.clear .title a::attr(href)').getall()
    for link in href:
        # url = 'https://cs.lianjia.com/ershoufang/104108664407.html'
        # 发送请求
        response = requests.get(url=link, headers=headers)
        # print(response)  # <Response [200]> 响应对象 200 状态码表示请求成功
        # 获取数据
        # print(response.text)
        """
        解析数据
            css选择器 >>> 根据标签属性内容提取数据
        """
        selector_1 = parsel.Selector(response.text)  # 需要把获取html字符串数据转成selector对象
        # print(selector)
        # 复制下来仅仅只是定位到标签, 我获取标签里面title属性
        try:
            # body > div.sellDetailHeader > div > div > div.title > h1
            title = selector_1.css('.main::text').get()  # 标题
            selling_point = selector_1.css('.sub::text').get()  # 卖点
            price = selector_1.css('.price .total::text').get()  # 总价
            unitPrice = selector_1.css('.unitPrice .unitPriceValue::text').get()  # 单价
            house_type = selector_1.css('.room .mainInfo::text').get()  # 户型
            subInfo = selector_1.css('.room .subInfo::text').get().split('/')  # 楼层
            floor = subInfo[0]  # 楼层
            num = re.findall('\d+', subInfo[1])[0]  # 共有楼层数
            furnish = selector_1.css('.type .subInfo::text').get().split('/')[-1]  # 装修
            face = selector_1.css('.type .mainInfo::text').get()  # 朝向
            date = re.findall('\d+', selector_1.css('.area .subInfo::text').get())  # 建造时间
            if len(date) == 0:
                date = '0'
            else:
                date = date[0]
            area = selector_1.css('.area .mainInfo::text').get().replace('平米', '')  # 面积
            community = selector_1.css('.communityName .info::text').get()  # 小区
            areaName_info = selector_1.css('.areaName .info a::text').getall()  # 区域
            areaName = areaName_info[0]  # 所属区
            region = areaName_info[1]  # 区域
            scale = selector_1.css('div.content ul li:nth-child(10)::text').get()  # 梯户比例
            elevator = selector_1.css('div.content ul li:nth-child(11)::text').get()  # 是否有电梯
            houseProperty = selector_1.css('div.content  li:nth-child(2) span:nth-child(2)::text').get()  # 房屋属性
            dit = {
                '标题': title,
                '卖点': selling_point,
                '总价': price,
                '单价': unitPrice,
                '户型': house_type,
                '楼层': floor,
                '共有楼层数': num,
                '装修': furnish,
                '朝向': face,
                '建造时间': date,
                '面积': area,
                '小区': community,
                '区域': region,
                '所属区': areaName,
                '梯户比例': scale,
                '是否有电梯': elevator,
                '房屋属性': houseProperty,
                '详情页': link,
            }
            csv_writer.writerow(dit)
            print(
                title, selling_point, price, unitPrice, house_type, subInfo, furnish, face,
                date, area, community, region, scale, elevator, houseProperty, link
            )
        except:
            pass


